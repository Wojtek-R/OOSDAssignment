import java.time.*;

public class Event
{
    public enum EventStatus {
        UNPUBLISHED,
        UPCOMING,
        IN_PROGRESS,
        RESCHEDULED,
        CANCELED
    }
    
    private int eventID;
    private String eventTitle;
    private String eventDesc;
    private LocalDateTime eventDate;
    private int promoID = -1;
    private EventStatus status = EventStatus.UNPUBLISHED;
    private LocalDateTime createdOn;
    private int createdBy;
    private LocalDateTime lastModified;
    private int modifiedBy;
    private int[] adultSeats;
    private double baseAdultPrice;
    private int[] childSeats;
    private double baseChildPrice;
    private int[] seniorSeats;
    private double baseSeniorPrice;
    private int[] studentSeats;
    private double baseStudentPrice;
    private int seatsPerCustomer = 1;
    
    public Event()
    {
    }
    
    public void setEventID(int eventID) {
        this.eventID = eventID;
    }
    
    public int getEventID() {
        return this.eventID;
    }
    
    public void setTitle(String title) {
        this.eventTitle = title;
    }
    
    public String getTitle() {
        return this.eventTitle;
    }
    
    public void setDescription(String description) {
        this.eventDesc = description;
    }
    
    public String getDescription() {
        return this.eventDesc;
    }
    
    public void setEventDate(LocalDateTime d) {
        this.eventDate = d;
    }
    
    public LocalDateTime getEventDate() {
        return this.eventDate;
    }
    
    public void setPromoID(int promoID) {
        this.promoID = promoID;
    }
    
    public int getPromoID() {
        return this.promoID;
    }
    
    public void setEventStatus(EventStatus status) {
        this.status = status;
    }
    
    public EventStatus getEventStatus() {
        return this.status;
    }
    
    public void setCreatedOn(LocalDateTime d) {
        this.createdOn = d;
    }
    
    public LocalDateTime getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedBy(int creatorID) {
        this.createdBy = creatorID;
    }
    
    public int getCreatedBy() {
        return this.createdBy;
    }
    
    public void setModifiedBy(int creatorID) {
        this.modifiedBy = creatorID;
    }
    
    public int getModifiedBy() {
        return this.modifiedBy;
    }
    
    public void setLastModified(LocalDateTime d) {
        this.lastModified = d;
    }
    
    public LocalDateTime getLastModified() {
        return this.lastModified;
    }
    
    public void setSeatsPerCustomer(int seatsPerCust) {
        this.seatsPerCustomer = seatsPerCust;
    }
    
    public int getSeatsPerCustomer() {
        return this.seatsPerCustomer;
    }
    
    public void setSeatDetails(int[][] seatID, double[] basePrices) 
    {
        this.adultSeats = seatID[0];
        this.childSeats = seatID[1];
        this.seniorSeats = seatID[2];
        this.studentSeats = seatID[3];
                                    
        this.baseAdultPrice = basePrices[0];
        this.baseChildPrice = basePrices[1];
        this.baseSeniorPrice = basePrices[2];
        this.baseStudentPrice = basePrices[3];
    }

    public Object[] getSeatDetails() {
        int[][] seatID = {this.adultSeats,
                            this.childSeats,
                            this.seniorSeats,
                            this.studentSeats};
        double[] basePrices = {this.baseAdultPrice,
                                this.baseChildPrice,
                                this.baseSeniorPrice,
                                this.baseStudentPrice};
        return new Object[] {seatID, basePrices};                    
    }
    
    public boolean proposeSeats(double priceFrom, double priceTo) {
        return true;
    }
    
}
