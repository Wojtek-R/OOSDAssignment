import java.util.*;
import java.time.LocalDate;

/**
 * A person class for a simple BlueJ demo program. Person is used as
 * an abstract superclass of more specific person classes.
 *a
 * @author  Michael Kolling
 * @version 1.0, January 1999
 * Extended by Patryk Bialon
 */

abstract class User
{   
    public enum UserType {
        BANNED,
        CONSUMER,
        AGENT,
        MANAGER
    }
    
    private Database db;
    private int userID;
    private UserType userType;
    private String username;
    private String password;
    private String fName;
    private String lName;
    private LocalDate DOB;
    private String stAddr;
    private String ndAddr;
    private String rdAddr;
    private String postcode;
    private String phone;
    private String email;
    private boolean email_confirmed;
    
    User(UserType userType, String username, String password, String fName, 
            String lName, String stAddr, String ndAddr, 
            String rdAddr, String postcode, String phone, 
            String email, boolean email_confirmed)
    {
        this.userType = userType;
        this.username = username;
        this.password = password;
        this.fName = fName;
        this.lName = lName;
        this.stAddr = stAddr;
        this.ndAddr = ndAddr;
        this.rdAddr = rdAddr;
        this.postcode = postcode;
        this.phone = phone;
        this.email = email;
        this.email_confirmed = email_confirmed;
        db = getDbLink();
    }

    /**
     * Set a new name for this person.
     */
    
    public boolean userRegister() {
        if(this.username.length() >= 3 || this.username.length() <= 32) {
        } 
        int nextID = 0;
        for(int i = 0; i < db.listAllUsers().size(); i++) {
            nextID = db.listAllUsers().get(i).getUserID() + 1;
        }
        this.userID = nextID;
        return db.addUser(this);
    }
    
    public boolean userLogin(String username, String pass) {
        boolean result = false;
        for(int i = 0; i < db.listAllUsers().size(); i++) {
            User u = db.listAllUsers().get(i);
            if(u.getUsername() == username && u.getPassword() == pass &&
            u.getUserType() == this.userType) {
                this.userID = u.getUserID();
                this.userType = u.getUserType();
                this.username = u.getUsername();
                this.password = u.getPassword();
                this.fName = u.getFName();
                this.lName = u.getLName();
                this.DOB = u.getDOB();
                this.stAddr = u.getStAddr();
                this.ndAddr = u.getNdAddr();
                this.rdAddr = u.getRdAddr();
                this.postcode = u.getPostCode();
                this.phone = u.getPhone();
                this.email = u.getEmail();
                this.email_confirmed = u.getEmailStatus();
                System.out.println("Logged succesfully!");
                result = true;
            }
        }
        System.out.println("Bad username or password!");
        return result;
    }
    
    public void setUserID(int userID) {
        this.userID = userID;
    }
    
    public int getUserID()
    {
        return this.userID;
    }
    
    public void setUserType(User.UserType newRank) {
        this.userType = newRank;
    }
    
    public UserType getUserType() {
        return this.userType;
    }
    
    public String getUsername()
    {
        return this.username;
    }

    public String getPassword()
    {
        return this.password;
    }

    public String getFName()
    {
        return this.fName;
    }

    public String getLName()
    {
        return this.lName;
    }
    
    public LocalDate getDOB()
    {
        return this.DOB;
    }
    
    public String getStAddr() {
        return this.stAddr;
    }
    
    public String getNdAddr() {
        return this.ndAddr;
    }
    
    public String getRdAddr() {
        return this.rdAddr;
    }
    
    public String getPostCode() {
        return this.postcode;
    }
    
    public String getPhone() {
        return this.phone;
    }
    
    public String getEmail() {
        return this.email;
    }
    
    
    public boolean getEmailStatus() {
        return this.email_confirmed;
    }
    
    public void setDbLink(Database dbLink) {
        this.db = dbLink;
    }
    
    public Database getDbLink() {
        return this.db;
    }
}
