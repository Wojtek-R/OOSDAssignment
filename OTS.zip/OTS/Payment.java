
public class Payment
{
    // instance variables - replace the example below with your own
    private int paymentID;
    private double amount;
    private boolean is_finalized = false;

    /**
     * Constructor for objects of class Payment
     */
    public Payment()
    {
    }
    
    public void setPaymentID(int paymentID) {
        this.paymentID = paymentID;
    }
    
    public int getPaymentID() {
        return paymentID;
    }
    
    public void setPaymentAmount(int payedAmount) {
        this.amount = payedAmount;
    }
    
    
    public void finalizePayment() {
        if(!is_finalized) this.is_finalized = true;
        else System.out.println("Payment is already finalized!" + 
                " ID: " + this.paymentID + ". Amount: " + this.amount +
                " Current status: " + this.is_finalized);
    }
}
