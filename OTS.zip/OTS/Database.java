import java.util.ArrayList;
import java.util.Iterator;

/**
 * A very simple database of people in a university. This class simply stores
 * persons and, at request, lists them on standard output.
 *
 * Written as a first demo program for BlueJ.
 *
 * @author  Michael Kolling
 * @version 1.1, March 2002
 * Extended by Patryk Bialon
 */

public class Database {

    private ArrayList<User> users;
    private ArrayList<Event> events;
    private ArrayList<SeatPromo> seatPromos;
    private ArrayList<EventPromo> eventPromos;
    private ArrayList<SeatOrder> seatOrders;
    private ArrayList<Contract> contracts;
    private ArrayList<Payment> payments;

    public static void main(String[] args) {
    }
    
    public Database() 
    {
        users = new ArrayList<User>();
        events = new ArrayList<Event>();
        seatPromos = new ArrayList<SeatPromo>();
        eventPromos = new ArrayList<EventPromo>();
        seatOrders = new ArrayList<SeatOrder>();
        contracts = new ArrayList<Contract>();
        payments = new ArrayList<Payment>();
    }

    /**
     * Add a person to the database.
     */
    public boolean addUser(User u) 
    {
        return users.add(u);
    }
    
    public boolean addEvent(Event e) 
    {
        return events.add(e);
    }
    
    public boolean addSeatPromo(SeatPromo s) 
    {
        return seatPromos.add(s);
    }
    
    public boolean addEventPromo(EventPromo e) 
    {
        return eventPromos.add(e);
    }
    
    public boolean addSeatOrder(SeatOrder s) 
    {
        return seatOrders.add(s);
    }
    
    public boolean addContract(Contract c) 
    {
        return contracts.add(c);
    }
    
    public boolean addPayment(Payment p) 
    {
        return payments.add(p);
    }

    /**
     * List all the persons currently in the database on standard out.
     */
    public ArrayList<User> listAllUsers() 
    {
        for (int i = 0; i < users.size(); i++) {
            System.out.println("UserID: " + users.get(i).getUserID() + " - " 
            + users.get(i).getUsername());
        }
        return users;
    }
    
    public ArrayList<Event> listAllEvents() 
    {
        for (int i = 0; i < events.size(); i++) {
            Event result = events.get(i);
            System.out.println(result.getTitle() + " - MakerID: " + result.getCreatedBy());
        }
        return events;
    }
    
    public ArrayList<SeatPromo> listAllSeatPromos() 
    {
        for (int i = 0; i < seatPromos.size(); i++) {
            SeatPromo result = seatPromos.get(i);
            System.out.println("seatPromo no. " + (i+1) + " has ID of " + result.getPromoID());
        }
        return seatPromos;
    }
    
    public ArrayList<EventPromo> listAllEventPromos() 
    {
        for (int i = 0; i < eventPromos.size(); i++) {
            EventPromo result = eventPromos.get(i);
            System.out.println("eventPromo no. " + (i+1) + " has ID of " + result.getPromoID());
        }
        return eventPromos;
    }
    
    public ArrayList<SeatOrder> listAllSeatOrders() 
    {
        for (int i = 0; i < seatOrders.size(); i++) {
            SeatOrder result = seatOrders.get(i);
            System.out.println("SeatOrder no. " + (i+1) + 
            " has ID of " + result.getOrderID() +
            " with paymentID of " + result.getPaymentID());
        }
        return seatOrders;
    }
    
    public ArrayList<Contract> listAllContracts() 
    {
        for (int i = 0; i < contracts.size(); i++) {
            Contract result = contracts.get(i);
            System.out.println("Contract no. " + (i+1) + " has ID of " + result.getContractID());
        }
        return contracts;
    }
    
    public ArrayList<Payment> listAllPayments() 
    {
        for (int i = 0; i < payments.size(); i++) {
            Payment result = payments.get(i);
            
            System.out.println("Payment no. " + (i+1) + " has ID of " + result.getPaymentID());
        }
        return payments;
    }
    
    public void clearDb(int which) {
        switch(which) {
            case 1: {
                users.clear();
                break;
            }
            case 2: {
                events.clear();
                break;
            }
            case 3: {
                seatPromos.clear();
                break;
            }
            case 4: {
                seatOrders.clear();
                break;
            }
            
            default: {
                users.clear();
                events.clear();
                seatPromos.clear();
                break;
            }
        }
    }
}
