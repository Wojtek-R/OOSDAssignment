import java.time.*;

public class Manager extends User
{   
    private static final UserType userType = UserType.MANAGER;
    public Manager(Database dbLink,
                    String username, 
                    String password, 
                    String fName,
                    String lName, 
                    String stAddr, 
                    String ndAddr,
                    String rdAddr, 
                    String postcode, 
                    String phone, 
                    String email,
                    boolean email_confirmation)
    {
        super(userType, username, password, fName, lName, stAddr, ndAddr,
                rdAddr, postcode, phone, email, email_confirmation);
        setDbLink(dbLink);
    }
    
    public Manager(Database dbLink) {
        super(userType, "", "", "", "", "", "", "", "", "", "", false);
        setDbLink(dbLink);
    }
    
    public boolean createEventPromo(LocalDateTime startDate,
                                    LocalDateTime endDate,
                                    double[] pricing) {
        Database db = getDbLink();
        int nextID = db.listAllEventPromos().size() == 0 ? 0 : db.listAllEventPromos().size();
        EventPromo e = new EventPromo();
        e.setPromoID(nextID);
        e.setCreatedOn(LocalDateTime.now());
        e.setCreatedBy(this.getUserID());
        e.setLastModified(LocalDateTime.now());
        e.setModifiedBy(this.getUserID());
        e.setStartDate(startDate);
        e.setEndDate(endDate);
        e.setPricing(pricing);
        boolean result = db.addEventPromo(e);
        return result;
    }    
    
    public void changeEventPromo(int eventPromoID, 
                                        LocalDateTime startDate, 
                                        LocalDateTime endDate,
                                        double[] pricing) {
        Database db = getDbLink();
        EventPromo e = db.listAllEventPromos().get(eventPromoID);
        e.setLastModified(LocalDateTime.now());
        e.setModifiedBy(this.getUserID());
        e.setStartDate(startDate);
        e.setEndDate(endDate);
        e.setPricing(pricing);
        db.listAllEventPromos().remove(eventPromoID);
        db.listAllEventPromos().add(eventPromoID, e);
    }
    
    public boolean assignEventPromo(int eventID, int promoID) {
        boolean result = false;
        Database db = getDbLink();
        Event e = db.listAllEvents().get(eventID);
        if(e.getPromoID() == -1) {
            e.setPromoID(promoID);
            db.listAllEvents().remove(eventID);
            db.listAllEvents().add(eventID, e);
            result = true;
        }
        return result;        
    }
        
    public boolean createSeatPromo(LocalDateTime startDate,
                                    LocalDateTime endDate, 
                                    int[] seatID, 
                                    double seatPrice) {
        Database db = getDbLink();
        int nextID = db.listAllSeatPromos().size() == 0 ? 
                        0 : db.listAllSeatPromos().size();
        SeatPromo s = new SeatPromo();
        s.setPromoID(nextID);
        s.setCreatedOn(LocalDateTime.now());
        s.setCreatedBy(this.getUserID());
        s.setLastModified(LocalDateTime.now());
        s.setModifiedBy(this.getUserID());
        s.setStartDate(startDate);
        s.setEndDate(endDate);
        s.setSeatID(seatID);
        s.setSeatPrice(seatPrice);
        boolean result = db.addSeatPromo(s);
        
        return result;
    }
        
    public boolean changeSeatPromo(int seatPromoID, LocalDateTime startDate,
                                    LocalDateTime endDate, 
                                    int[] seatID, 
                                    double seatPrice) {
        Database db = getDbLink();
        SeatPromo s = db.listAllSeatPromos().get(seatPromoID);
        s.setLastModified(LocalDateTime.now());
        s.setModifiedBy(this.getUserID());
        s.setStartDate(startDate);
        s.setEndDate(endDate);
        s.setSeatID(seatID);
        s.setSeatPrice(seatPrice);
        db.listAllSeatPromos().remove(seatPromoID);
        db.listAllSeatPromos().add(seatPromoID, s);        
        return true;
    }
    
    public boolean createEvent(String eventTitle,
                                String eventDesc,
                                LocalDateTime eventDate,
                                int eventPromoID,
                                Event.EventStatus eventStatus,
                                int[][] seatID,
                                double[] basePrices,
                                int seatsPerCustomer) {
        Database db = getDbLink();
        int nextID = db.listAllEvents().size() == 0 ? 
                        0 : db.listAllEvents().size();    
        Event e = new Event();
        e.setEventID(nextID);
        e.setTitle(eventTitle);
        e.setDescription(eventDesc);
        e.setEventDate(eventDate);
        e.setPromoID(eventPromoID);
        e.setEventStatus(eventStatus);
        e.setCreatedOn(LocalDateTime.now());
        e.setCreatedBy(this.getUserID());
        e.setLastModified(LocalDateTime.now());
        e.setModifiedBy(this.getUserID());
        e.setSeatDetails(seatID, basePrices);
        e.setSeatsPerCustomer(seatsPerCustomer);
        boolean result = db.addEvent(e);
        
        return result;
    }
    
    public boolean modifyEvent(int eventID,
                                String eventTitle,
                                String eventDesc,
                                LocalDateTime eventDate,
                                int eventPromoID,
                                Event.EventStatus eventStatus,
                                int[][] seatID,
                                double[] basePrices) {
        Database db = getDbLink();
        
        Event e = db.listAllEvents().get(eventID);
        e.setTitle(eventTitle = eventTitle == null ? e.getTitle() : eventTitle);
        e.setDescription(eventDesc);
        e.setEventDate(eventDate);
        e.setPromoID(eventPromoID);
        e.setEventStatus(eventStatus);
        e.setCreatedOn(LocalDateTime.now());
        e.setCreatedBy(this.getUserID());
        e.setLastModified(LocalDateTime.now());
        e.setModifiedBy(this.getUserID());
        e.setSeatDetails(seatID, basePrices);
        db.listAllEvents().remove(eventID);
        db.listAllEvents().add(eventID, e);
        
        return true;
    }
        
        
    public boolean cancelEvent(int eventID) {
        Database db = getDbLink();
        Event e = db.listAllEvents().get(eventID);
        if(e.getEventStatus() != Event.EventStatus.CANCELED) {
            e.setEventStatus(Event.EventStatus.CANCELED);
            db.listAllEvents().remove(eventID);
            db.listAllEvents().add(eventID, e);
            return true;
        }
        return false;
    }
    
    public boolean elevateUser(int userID, User.UserType newRank) {
        boolean result = false;
        Database db = getDbLink();
        User u = db.listAllUsers().get(userID); 
        if(u.getUserType() == User.UserType.CONSUMER || 
        u.getUserType()  == User.UserType.AGENT) {
            switch(newRank) {
                case AGENT: {
                    if(newRank != User.UserType.MANAGER) break;
                    
                    Agent a = new Agent(db, u.getUsername(), u.getPassword(),
                                        u.getFName(), u.getLName(), u.getStAddr(),
                                        u.getNdAddr(), u.getRdAddr(), u.getPostCode(),
                                        u.getPhone(), u.getEmail(), getEmailStatus());
                    a.setUserType(newRank);
                    db.listAllUsers().remove(userID);
                    db.listAllUsers().add(userID, a);
                    result = true;
                    break;
                }
                case MANAGER: {
                    Manager m = new Manager(db, u.getUsername(), u.getPassword(),
                                        u.getFName(), u.getLName(), u.getStAddr(),
                                        u.getNdAddr(), u.getRdAddr(), u.getPostCode(),
                                        u.getPhone(), u.getEmail(), getEmailStatus());
                    
                    m.setUserType(newRank);
                    db.listAllUsers().remove(userID);
                    db.listAllUsers().add(userID, m);
                    result = true;
                    break;
                }
            }
        };
        return result;
    }
    
    public void deleteUserAccount(int userID) {
        Database db = getDbLink();
        for(int i = 0; i < db.listAllUsers().size(); i++) if(userID == db.listAllUsers().get(i).getUserID()) db.listAllUsers().remove(i);
    }
    
    public boolean createContract() {
        Database db = getDbLink();
        int nextID = db.listAllContracts().size() == 0 ? 0 : db.listAllContracts().size();
        Contract c = new Contract();
        c.setContractID(nextID); 
        boolean result = db.addContract(c);
        
        return result;
    }
    
}
