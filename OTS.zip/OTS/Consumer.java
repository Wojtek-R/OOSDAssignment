import java.time.*;

public class Consumer extends User
{
    private static final UserType userType = UserType.CONSUMER;
    private int contractID;
    /**
     * Constructor for objects of class Consumer
     */
    public Consumer(Database dbLink, 
                    String username, 
                    String password, 
                    String fName,
                    String lName,  
                    String stAddr, 
                    String ndAddr,
                    String rdAddr, 
                    String postcode, 
                    String phone, 
                    String email,
                    boolean email_confirmed)
    {
        super(userType, username, password, fName, lName, stAddr, ndAddr,
                rdAddr, postcode, phone, email, email_confirmed);
        setDbLink(dbLink);
    }
    
    
    public Consumer(Database dbLink) {
        super(userType, "", "", "", "", "", "", "", "", "", "", false);
        setDbLink(dbLink);
        
        Database db = getDbLink();
        
        int[][] seatID = {{1,2,3},{4,5,6},{7,8,9},{10,11,12}};
        double[] prices = {5,10,15,20};
        int nextID = db.listAllEvents().size() == 0 ? 
                        0 : db.listAllEvents().size();    
        Event e = new Event();
        e.setEventID(nextID);
        e.setSeatDetails(seatID, prices);
        db.addEvent(e);
    }
    //{{1,2,3},{4,5,6},{7,8,9},{10,11,12}}
    //{5,10,15,20}
    public boolean reserveSeats(int eventID, int[] seatID) {
        boolean result = false;
        Database db = getDbLink();
        
        Event e = db.listAllEvents().get(eventID);
        Object[] seatDetails = e.getSeatDetails();
        int[][] availableSeatID = (int[][])seatDetails[0];
        
        int nextSeatOrderID = 0;
        SeatOrder s = new SeatOrder();
        for(int i = 0; i < db.listAllSeatOrders().size(); i++) nextSeatOrderID = db.listAllSeatOrders().get(i).getOrderID() + 1;
        s.setOrderID(nextSeatOrderID);
        s.setEventID(eventID);
        s.setReservedBy(this.getUserID());
        s.setReservedFor(this.getUserID());
        s.setReservedDate(LocalDateTime.now());
        int seatsPerCust = e.getSeatsPerCustomer();
        
        int[] seatsReserved = new int[seatsPerCust];
        
        for(int i = 0; i < 4; i++) {
            for(int j = 0; j < availableSeatID[i].length; j++) {
                //System.out.println(availableSeatID[i][j]);
                for(int k = 0; k < (seatID.length > seatsPerCust ? seatsPerCust : seatID.length); k++) {
                    if(availableSeatID[i][j] == seatID[k]) {
                        
                    }
                }
            }
        }
        
        
        e.setSeatDetails(availableSeatID, (double[])seatDetails[1]);
        db.listAllEvents().remove(eventID);
        db.listAllEvents().add(eventID, e);
        s.setReservedSeats(seatsReserved);
        result = db.addSeatOrder(s);
        
        return result;
    }
    
    public boolean changeSeatReservation(int eventID, int seatOrderID, int[] newSeats) {
        return true;
    }
    
    public boolean orderSeat() {
        Database db = getDbLink();
        int nextID = db.listAllSeatOrders().size() == 
        0 ? 0 : db.listAllSeatOrders().size();
        SeatOrder s = new SeatOrder();
        s.setOrderID(nextID); 
        boolean result = db.addSeatOrder(s);
        
        return result;
    }
    
    public boolean orderPayment(int amount, int orderID, int paymentMethod) {
        boolean result = false;
        Database db = getDbLink();
        SeatOrder o = db.listAllSeatOrders().get(orderID);
        if(o.getPaymentID() == -1) {
            int nextID = db.listAllPayments().size() == 0 ? 0 : db.listAllPayments().size();
            Payment p = new Payment();
            p.setPaymentID(nextID);
            p.setPaymentAmount(amount);
            result = db.addPayment(p);
            if(result) {
                o.attachPayment(p.getPaymentID());
                db.listAllSeatOrders().remove(orderID);
                db.listAllSeatOrders().add(orderID, o);
                if(db.listAllSeatOrders().get(orderID).getPaymentID() != -1) {
                    p.finalizePayment();
                    db.listAllPayments().remove(p.getPaymentID());
                    db.listAllPayments().add(p.getPaymentID(), p);
                }
                return result;
            }
        }
        return result;
    }
    
    
}
