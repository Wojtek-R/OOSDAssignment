import java.time.*;

public class SeatOrder
{
    private int seatOrderID;
    private int eventID;
    private int reservedBy;
    private int reservedFor;
    private LocalDateTime reservedDate;
    private int[] reservedSeats;
    private int paymentID = -1;
    private LocalDateTime dateSold;

    /**
     * Constructor for objects of class SeatOrder
     */
    public SeatOrder()
    {
        
    }
    
    public void setOrderID(int ID) {
        this.seatOrderID = ID;
    }
    
    public int getOrderID() {
        return this.seatOrderID;
    }
    
    public void setEventID(int eventID) {
        this.eventID = eventID;
    }
    
    public int getEventID() {
        return this.eventID;
    }
    
    public void setReservedBy(int reservedBy) {
        this.reservedBy = reservedBy;
    }
    
    public int getReservedBy() {
        return this.reservedBy;
    }
    
    public void setReservedFor(int reservedFor) {
        this.reservedFor = reservedFor;
    }
    
    public int getReservedFor() {
        return this.reservedFor;
    }
    
    public void setReservedDate(LocalDateTime reservationDate) {
        this.reservedDate = reservationDate;
    }
    
    public LocalDateTime getReservedDate() {
        return this.reservedDate;
    }
    
    public void setReservedSeats(int[] seatID) {
        this.reservedSeats = seatID;
    }
    
    public int[] getReservedSeats() {
        return this.reservedSeats;
    }
    
    public void setPaymentID(int paymentID) {
        this.paymentID = paymentID;
    }
    
    public int getPaymentID() {
        return this.paymentID;
    }

    public void setSellDate(LocalDateTime soldDate) {
        this.dateSold = soldDate;
    }
    
    public LocalDateTime getSellDate() {
        return this.dateSold;
    }
    
    public void attachPayment(int paymentID) {
        this.paymentID = paymentID;
    }
}
