import java.util.*;

public class Contract
{
    private int contractID;
    private int managerID;
    private int agentID;
    private double commisionValue;
    private String TNC;
    private Date dateSigned;
    private Date expiryDate;
    private boolean is_active;
    private int[] seatID;

    /**
     * Constructor for objects of class Contract
     */
    public Contract()
    {
    }
    
    public void setContractID(int ID) {
        this.contractID = ID;
    }
    
    public int getContractID() {
        return this.contractID;
    }
}
