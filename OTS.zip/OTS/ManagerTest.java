

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class ManagerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ManagerTest
{
    private Database TestDataBase;
    private Manager manager1;

    /**
     * Default constructor for test class ManagerTest
     */
    public ManagerTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        TestDataBase = new Database();
        manager1 = new Manager(TestDataBase);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }

    @Test
    public void CreateEventPromo()
    {
        double[] pricing = {15.00,10.00,12.00,20.00};
        manager1.createEventPromo(null, null, pricing);
    }
}





