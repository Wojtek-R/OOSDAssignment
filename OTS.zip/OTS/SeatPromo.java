import java.time.*;

public class SeatPromo
{
    
    private int seatPromoID;
    private LocalDateTime createdOn;
    private int createdBy;
    private LocalDateTime lastModified;
    private int modifiedBy;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private int[] seatID;
    private double seatPrice;
    

    /**
     * Constructor for objects of class SeatPromo
     */
    public SeatPromo()
    {
    }
    
    public void setPromoID(int ID) {
        this.seatPromoID = ID;
    }
    
    public int getPromoID() {
        return this.seatPromoID;
    }
    
    public void setCreatedOn(LocalDateTime d) {
        this.createdOn = d;
    }
    
    public LocalDateTime getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedBy(int creatorID) {
        this.createdBy = creatorID;
    }
    
    public int getCreatedBy() {
        return this.createdBy;
    }
    
    public void setModifiedBy(int creatorID) {
        this.modifiedBy = creatorID;
    }
    
    public int getModifiedBy() {
        return this.modifiedBy;
    }
    
    public void setLastModified(LocalDateTime d) {
        this.lastModified = d;
    }
    
    public LocalDateTime getLastModified() {
        return this.lastModified;
    }
    
    public void setStartDate(LocalDateTime d) {
        this.startDate = d;
    }
    
    public LocalDateTime getStartDate() {
        return this.startDate;
    }
    
    public void setEndDate(LocalDateTime d) {
        this.endDate = d;
    }
    
    public LocalDateTime getEndDate() {
        return this.endDate;
    }
    
    public void setSeatID(int[] seatID) {
        this.seatID = seatID;
    }
    
    public int[] getSeatID() {
        return this.seatID;
    }
    
    public void setSeatPrice(double seatPrice) {
        this.seatPrice = seatPrice;
    }
    
    public double getSeatPrice() {
        return this.seatPrice;
    }
}
