import java.time.LocalDate;

public class Agent extends User
{   
    private static final UserType userType = UserType.AGENT;
    public Agent(Database dbLink,
                    String username, 
                    String password, 
                    String fName,
                    String lName,  
                    String stAddr, 
                    String ndAddr,
                    String rdAddr, 
                    String postcode, 
                    String phone, 
                    String email,
                    boolean email_confirmed)
    {
        super(userType, username, password, fName, lName, stAddr, ndAddr,
                rdAddr, postcode, phone, email, email_confirmed);
        setDbLink(dbLink);
    }
    
    
    public Agent(Database dbLink) {
        super(userType, "", "", "", "", "", "", "", "", "", "", false);
        setDbLink(dbLink);
    }
    
    public boolean showUserEvents() {
        boolean result = false;
        return result;
    }
    
    public boolean reserveForCust() {
        boolean result = false;
        return result;
    }
}
