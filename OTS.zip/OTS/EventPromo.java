import java.time.*;

public class EventPromo
{
    private int eventPromoID;
    private LocalDateTime createdOn;
    private int createdBy;
    private LocalDateTime lastModified;
    private int modifiedBy;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private double adultPrice;
    private double studentPrice;
    private double seniorPrice;
    private double childPrice;

    /**
     * Constructor for objects of class EventPromo
     */
    public EventPromo()
    {
        
    }
    
    public void setPromoID(int ID) {
        this.eventPromoID = ID;
    }
    
    public int getPromoID() {
        return this.eventPromoID;
    }
    
    public void setCreatedOn(LocalDateTime d) {
        this.createdOn = d;
    }
    
    public LocalDateTime getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedBy(int creatorID) {
        this.createdBy = creatorID;
    }
    
    public int getCreatedBy() {
        return this.createdBy;
    }
    
    public void setModifiedBy(int creatorID) {
        this.modifiedBy = creatorID;
    }
    
    public int getModifiedBy() {
        return this.modifiedBy;
    }
    
    public void setLastModified(LocalDateTime d) {
        this.lastModified = d;
    }
    
    public LocalDateTime getLastModified() {
        return this.lastModified;
    }
    
    public void setStartDate(LocalDateTime d) {
        this.startDate = d;
    }
    
    public LocalDateTime getStartDate() {
        return this.startDate;
    }
    
    public void setEndDate(LocalDateTime d) {
        this.endDate = d;
    }
    
    public LocalDateTime getEndDate() {
        return this.endDate;
    }
    
    public void setPricing(double[] pricing) {
        this.adultPrice = pricing[0];
        this.childPrice = pricing[1];
        this.studentPrice = pricing[2];
        this.seniorPrice = pricing[3];
    }
    
    public double[] getPricing() {
        double[] pricing = {this.adultPrice, 
                            this.childPrice, 
                            this.studentPrice,
                            this.seniorPrice
                        };
        return pricing;
    }
}
